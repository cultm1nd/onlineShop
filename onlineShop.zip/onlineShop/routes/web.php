<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\KorzinaController;
use Illuminate\Support\Facades\Auth;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//about
Route::get('/about', function () {
    return view('aboutUs');
});
//katalog
Route::get('/katalog', [ProductController::class, 'getProduct']);
Route::post('/katalog', [ProductController::class, 'postProduct']);
//where
Route::get('/where', function () {
    return view('where');
});
//korzina
Route::get('/korzina', [KorzinaController::class, 'getKorzina']);


Route::post('/login', [UserController::class, 'SignIn']);


//signin
Route::get('/login', function () {
    if (Auth::check()) {
        return redirect('/katalog');
    }
    return view('login');
});
//reg
Route::get('/reg', function () {
    return view('registration');
});
Route::post('/reg', [UserController::class, 'SignUp']);
//exit
Route::get('/logout', function () {
    Auth::logout();
    return redirect(to: '/');
})->name(name: 'logout');
