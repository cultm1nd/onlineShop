<div class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
    <p class="col-md-4 mb-0 text-body-secondary">© 2024 Company, CopyStar</p>
    <ul class="nav col-md-4 justify-content-end">
      <li class="nav-item"><a href = '{{URL::to('/about')}}' class="nav-link px-2 text-body-secondary">О нас</a></li>
      <li class="nav-item"><a href = '{{URL::to('/katalog')}}' class="nav-link px-2 text-body-secondary">Каталог</a></li>
      <li class="nav-item"><a href = '{{URL::to('/where')}}' class="nav-link px-2 text-body-secondary">Где нас найти?</a></li>
    </ul>
</div>
