<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use App\Models\User;
use App\Models\Product;
use App\Models\Korzina;
use App\Models\Korzina_product;
use Illuminate\Support\Facades\DB;

class KorzinaController extends Controller
{
    public function getKorzina()
    {
        $id_korzina = DB::table('korzina')->where('id_user', Auth::id())->where('status', 'select')->first();
        $productsFromKorzina = DB::table('korzina_product')->where('id_korzina', $id_korzina->id_korzina)->select('id_product')->get();
        $products = DB::table('products')->where('count', '>', 0)->get();
        return view('korzina', ['products' => $products, 'productsFromKorzina' => $productsFromKorzina]);
    }
}
