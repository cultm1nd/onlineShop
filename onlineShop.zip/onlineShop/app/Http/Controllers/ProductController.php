<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use App\Models\User;
use App\Models\Product;
use App\Models\Korzina;
use App\Models\Korzina_product;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{

    public function getProduct()
    {
        if (Auth::check()) {

            $products = DB::table('products')->where('count', '>', 0)->get();
            $id_korzina = DB::table('korzina')->where('id_user', Auth::id())->where('status', 'select')->first();
            $productsFromKorzina = DB::table('korzina_product')->where('id_korzina', $id_korzina->id_korzina)->select('id_product')->get();
            return view('katalog', ['products' => $products, 'productsFromKorzina' => $productsFromKorzina]);
        }
        $products = DB::table('products')->where('count', '>', 0)->get();
        return view('katalog', ['products' => $products]);
    }
    public function postProduct(Request $request)
    {
        //проверка на добавление
        $id_korzina = DB::table('korzina')->where('id_user', Auth::id())->where('status', 'select')->first();
        $productsFromKorzina = DB::table('korzina_product')->where('id_korzina', $id_korzina->id_korzina)->select('id_product')->get();
        if (isset($_POST['add'])) {
            $id = $request->input('add');
            DB::table('korzina_product')->insert([
                'id_korzina' => $id_korzina->id_korzina,
                'id_product' => $id,
                'count' => 1,
            ]);
        }
        if (isset($_POST['del'])) {
            $id = $request->input('del');
            DB::table('korzina_product')->where('id_korzina', $id_korzina->id_korzina)->where('id_product', $id)->delete();
        }

        $products = DB::table('products')->where('count', '>', 0)->get();
        $productsFromKorzina = DB::table('korzina_product')->where('id_korzina', $id_korzina->id_korzina)->select('id_product')->get();
        return view('katalog', ['products' => $products, 'productsFromKorzina' => $productsFromKorzina]);
    }
}
