<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

use App\Models\User;
use App\Models\Product;
use App\Models\Korzina;
use App\Models\Korzina_product;

class UserController extends Controller
{

    //reg
    public function SignUp(Request $request)
    {
        $validateFiels = $request->validate([
            'name' => 'required',
            'surname' => 'required',
            'login' => 'required',
            'email' => 'required|email',
            'password' => 'required',
        ]);

        //$user = User::create($validateFiels);
        $user = User::create(['name' => $validateFiels['name'], 'surname' => $validateFiels['surname'], 'login' => $validateFiels['login'], 'email' => $validateFiels['email'], 'password' => $validateFiels['password']]);

        Auth::login($user);
        // $this->CreateKorzina();
        DB::table('korzina')->insert([
            'id_user' => $user->id,
            'status' => 'select',

        ]);
        return redirect('/about');
    }
    //vhod
    public function SignIn(Request $request)
    {
        $foundFields = $request->only(['login', 'password']);

        if (Auth::attempt($foundFields)) {
            if (Auth::user()->isAdmin) {
                return redirect('/admin');
            }

            return redirect('/katalog');
        }

        return redirect('/login');
    }
}
